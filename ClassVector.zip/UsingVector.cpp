#include <iostream>
#include "Vector.cpp"

using namespace std;

int main(int argc, char* argv[])
{
    Vector u;
    
    u.x = 13.0;
    u.y = 1.0;
    u.z = 64.0;
    
    Vector v;
    
    v.x = 0.0;
    v.y = 1.0;
    v.z = 2.0;
    
    Vector w;
    w = u + v;
    w = w *-1;
    cout << w.x <<","<< w.y << endl; 
}