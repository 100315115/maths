#ifndef VECTORHEADERDEF
#define VECTORHEADERDEF

class Vector
{
public:
    double x;
    double y;
    double z;
    Vector();
    Vector(double x, double y, double z);
    Vector operator+(const Vector& u) const;
    Vector operator*(double s);
};
#endif
