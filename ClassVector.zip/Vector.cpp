#include "Vector.hpp"
Vector::Vector()
{
   x=0.0;
   x=0.0;
   x=0.0;
}

Vector::Vector(double xp, double yp, double zp)
{
   x=xp;
   x=yp;
   x=zp;
}

Vector Vector::operator+(const Vector& u) const
{  Vector w;
   w.x = x + u.x;
   w.y = y + u.y;
   w.z = z + u.z;
   return w;
}

Vector Vector::operator*(double s)
{  Vector w;
   w.x = s * x;
   w.y = s * y;
   w.z = s * z;
   return w;
}