#include "EE1+1.hpp"

double Fitness(vector <double> values) // Replace maximices PENSAR BIEN ESTO!!!
{
    return ((3 * values[0]) + (4 * values[1]));
}



int main(int argc, char* argv[])
{   
    
    Evo test;
    
    //Generation of the first individual
    test.values_1 = {1, 2};
    test.sigmas_1 = {0.1, 0.2};
    
    //--------------------------------------------------------------------------
    
    int individual_size = test.values_1.size();
    
    
    //Inizialization of more test parameters
    test.generations = 50;
    test.window_size = 10;
    
    for(int i = 0 ; i < test.window_size; i++)
    {
        test.results.push_back(false); 
    }
    
    
    //--------------------------------------------------------------------------
    
    int generations_counter = 0;
    
    
    while(generations_counter <= test.generations)
    {
        //Mutation of values and sigmas to create a second individual 
        test.MutateValues(individual_size, generations_counter); 
        
        test.ratio = 0.0;    
        for (int i = 0; i < test.window_size; i++)
        {   
            if (test.results[i] == true)
            test.ratio = (test.ratio + 1)/test.window_size;
        }
        
        test.MutateSigmas(individual_size, test.ratio); // hacer lo que tu ya sabes carmen
        
        //Evaluate individual 1 and individual 2
        test.punctuation1 = Fitness(test.values_1);
        cout << test.punctuation1 << endl;
        test.punctuation2 = Fitness(test.values_2);
        cout << test.punctuation2 << endl;
        cout << endl;
        
        
        //Replacement
        test.Replace(generations_counter, individual_size);
        
        generations_counter++;
    }   

}