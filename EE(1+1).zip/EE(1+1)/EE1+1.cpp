#include "EE1+1.hpp"
#include <random>

void Evo::MutateValues(int individual_size, int generations_counter)
{   
    default_random_engine generator(generations_counter);
    if (values_2.size() == 0)
    {
        for(int i = 0; i < individual_size; i++)
        {   
            normal_distribution <double> distribution(0.0,sigmas_1[i]);
            
            values_2.push_back(values_1[i] + distribution(generator)); 
            sigmas_2.push_back(0.0);
            
            cout << values_2[i] << ' ';
            
        }
        
        cout << endl;
    }
    else
    {
        for(int i = 0; i < individual_size; i++)
        {   
            normal_distribution <double> distribution(0.0,sigmas_1[i]);
            
            values_2[i] = values_1[i] + distribution(generator);    
            
            cout << values_2[i] << ' ';
        }
    
        cout << endl;
    }
}


void Evo::MutateSigmas(int individual_size, double ratio)
{
    if(ratio < (1/5))
    {
        for(int i = 0; i < individual_size; i++)
        {
            sigmas_2[i] = 0.82 * sigmas_1[i]; //the value must be below 1.0
        }
    }
    else if(ratio > (1/5))
    {
        for(int i = 0; i < individual_size; i++)
        {
            sigmas_2[i] = 1.18 * sigmas_1[i];  //the value must be avobe 1.0
        }
    }
    else
    {
        for(int i = 0; i < individual_size; i++)
        {
            sigmas_2[i] = sigmas_1[i]; 
        }
    }
    
}

void Evo::Replace(int generations_counter, int individual_size)
{
    if (punctuation1 <= punctuation2)
    {
        
        for(int i = 0; i < individual_size; i++)
        {
            values_1[i] = values_2[i];
            sigmas_1[i] = sigmas_2[i];
        }
        
        results[generations_counter % window_size] = true;
        
    }
    
    else
    {
        results[generations_counter % window_size] = true;
    }
}