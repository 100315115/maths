#ifndef EVOHEADERDEF
#define EVOHEADERDEF

#include<vector>
#include <iostream>

using namespace std;

class Evo
{
public:
    vector <double> values_1;
    vector <double> sigmas_1;
    
    vector <double> values_2;
    vector <double> sigmas_2;
    
    int generations;
    
    int window_size;
    vector <bool> results;
    
    double ratio;
    
    double punctuation1;
    double punctuation2;
    
    void MutateValues(int individual_size, int generations_counter);
    void MutateSigmas(int individual_size, double ratio);
    void Replace(int generations_counter, int individual_size);
};
#endif
